# LS1 VPW Data Logger

Purpose-built starting point for a 1999 Chevrolet Camaro Z28 LS1, PCM OS 12202088.

## Current implementation

- Bluetooth Classic SPP / ELM327 connection
- SAE J1850 VPW protocol selection
- Standard OBD-II polling:
  - RPM (010C)
  - vehicle speed (010D)
  - IAT (010F)
  - MAP (010B)
  - TPS (0111)
- Raw TX/RX traffic display
- Live data display
- Read-only diagnostic operation

## GM enhanced data

The 1999 Camaro service information lists Current Gear and Knock Retard as scan-tool parameters, but their GM enhanced request/decoder definitions should not be guessed. The project therefore leaves Gear, Knock Count, and Knock Retard nullable until the verified GM request/decoder definitions for the target PCM are added.

## Important hardware note

The PCM uses GM J1850 VPW/Class 2 communication. A Bluetooth adapter must actually support VPW; many inexpensive ELM327 clones do not.

## Next development steps

1. Add verified GM enhanced requests/decoders for OS 12202088.
2. Add CSV streaming to Android app-private/exportable storage.
3. Add configurable sample rate.
4. Add foreground service for screen-off logging.
5. Add selectable paired adapter.
6. Add CSV export/share.
7. Add decoder unit tests and prerecorded raw-response test fixtures.
