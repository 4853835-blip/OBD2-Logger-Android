package com.ls1logger

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.io.BufferedInputStream
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

private val SPP_UUID: UUID =
    UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

data class LiveData(
    val rpm: Double? = null,
    val mph: Double? = null,
    val gear: Int? = null,
    val iatF: Double? = null,
    val knockCount: Int? = null,
    val knockRetard: Double? = null,
    val mapKpa: Double? = null,
    val tps: Double? = null
)

class MainActivity : ComponentActivity() {
    private val vm = LoggerViewModel()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestBtPermissions()
        setContent { LS1LoggerScreen(vm) }
    }

    private fun requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                )
            )
        }
    }
}

class LoggerViewModel {
    var status by mutableStateOf("Disconnected")
        private set
    var rawTraffic by mutableStateOf<List<String>>(emptyList())
        private set
    var live by mutableStateOf(LiveData())
        private set
    var logging by mutableStateOf(false)
        private set

    private val adapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var socket: BluetoothSocket? = null
    private var out: OutputStream? = null
    private var input: BufferedInputStream? = null
    private var worker: Thread? = null

    fun pairedDevices(): List<BluetoothDevice> =
        try { adapter?.bondedDevices?.toList() ?: emptyList() } catch (_: SecurityException) { emptyList() }

    fun connect(device: BluetoothDevice) {
        disconnect()
        status = "Connecting..."
        worker = thread(start = true, name = "ELM327") {
            try {
                val s = device.createRfcommSocketToServiceRecord(SPP_UUID)
                s.connect()
                socket = s
                out = s.outputStream
                input = BufferedInputStream(s.inputStream)
                status = "Bluetooth connected"
                initializeElm()
                pollLoop()
            } catch (e: Exception) {
                status = "Connection error: ${e.message ?: "unknown"}"
                disconnect()
            }
        }
    }

    private fun initializeElm() {
        send("ATZ")
        Thread.sleep(1500)
        send("ATE0")
        send("ATL0")
        send("ATS0")
        send("ATH1")
        send("ATSP2") // SAE J1850 VPW
        send("ATDP")
    }

    private fun send(command: String) {
        val bytes = (command.trim() + "\r").toByteArray(Charsets.US_ASCII)
        out?.write(bytes)
        out?.flush()
        addRaw("TX  $command")
    }

    private fun readResponse(timeoutMs: Long = 600L): String {
        val i = input ?: return ""
        val start = System.currentTimeMillis()
        val buffer = StringBuilder()
        while (System.currentTimeMillis() - start < timeoutMs) {
            while (i.available() > 0) {
                val c = i.read().toChar()
                if (c == '>') return buffer.toString().trim()
                buffer.append(c)
            }
            Thread.sleep(5)
        }
        return buffer.toString().trim()
    }

    private fun requestPid(pid: String): String {
        send(pid)
        val response = readResponse()
        addRaw("RX  $response")
        return response
    }

    private fun pollLoop() {
        while (socket?.isConnected == true) {
            try {
                val rpm = decodeRpm(requestPid("010C"))
                val mph = decodeSpeed(requestPid("010D"))
                val iat = decodeIat(requestPid("010F"))
                val map = decodeMap(requestPid("010B"))
                val tps = decodeTps(requestPid("0111"))

                live = live.copy(rpm = rpm, mph = mph, iatF = iat, mapKpa = map, tps = tps)

                // GM enhanced fields intentionally remain nullable until
                // verified request/decoder definitions are added for this PCM.
                Thread.sleep(50)
            } catch (e: Exception) {
                status = "Polling error: ${e.message ?: "unknown"}"
                break
            }
        }
    }

    private fun hexBytes(response: String): List<Int> =
        response.split(Regex("\\s+"))
            .mapNotNull { it.toIntOrNull(16) }

    private fun payload(response: String, pid: Int): List<Int>? {
        val b = hexBytes(response)
        for (i in 0 until b.size - 1) {
            if (b[i] == 0x41 && b[i + 1] == pid) return b.drop(i + 2)
        }
        return null
    }

    private fun decodeRpm(r: String): Double? {
        val p = payload(r, 0x0C) ?: return null
        if (p.size < 2) return null
        return ((p[0] * 256 + p[1]) / 4.0)
    }

    private fun decodeSpeed(r: String): Double? {
        val p = payload(r, 0x0D) ?: return null
        return p.firstOrNull()?.toDouble()
    }

    private fun decodeIat(r: String): Double? {
        val p = payload(r, 0x0F) ?: return null
        return p.firstOrNull()?.minus(40.0)
    }

    private fun decodeMap(r: String): Double? {
        val p = payload(r, 0x0B) ?: return null
        return p.firstOrNull()?.toDouble()
    }

    private fun decodeTps(r: String): Double? {
        val p = payload(r, 0x11) ?: return null
        return p.firstOrNull()?.times(100.0)?.div(255.0)
    }

    fun addRaw(line: String) {
        rawTraffic = (rawTraffic + line).takeLast(200)
    }

    fun startLog() { logging = true }
    fun stopLog() { logging = false }

    fun disconnect() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        out = null
        input = null
        status = "Disconnected"
    }
}

@Composable
fun LS1LoggerScreen(vm: LoggerViewModel) {
    val devices = remember { vm.pairedDevices() }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("LS1 VPW DATA LOGGER", style = MaterialTheme.typography.headlineSmall)
                    Text("1999 Camaro Z28 • OS 12202088")
                    Text(vm.status)
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { if (devices.isNotEmpty()) vm.connect(devices.first()) }) {
                            Text("CONNECT")
                        }
                        Button(onClick = { vm.disconnect() }) { Text("DISCONNECT") }
                    }
                }

                item { LivePanel(vm.live) }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.startLog() }) { Text("START LOG") }
                        Button(onClick = { vm.stopLog() }) { Text("STOP LOG") }
                    }
                    Text(if (vm.logging) "LOGGING" else "NOT LOGGING")
                }

                item { Text("Paired Bluetooth devices", style = MaterialTheme.typography.titleMedium) }
                items(devices) { d ->
                    TextButton(onClick = { vm.connect(d) }) {
                        Text(d.name ?: d.address)
                    }
                }

                item { Text("RAW TRAFFIC", style = MaterialTheme.typography.titleMedium) }
                items(vm.rawTraffic) { line -> Text(line) }
            }
        }
    }
}

@Composable
fun LivePanel(d: LiveData) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("RPM: ${d.rpm?.let { "%.0f".format(it) } ?: "--"}")
        Text("MPH: ${d.mph?.let { "%.0f".format(it) } ?: "--"}")
        Text("GEAR: ${d.gear ?: "--"}")
        Text("IAT °F: ${d.iatF?.let { "%.1f".format(it) } ?: "--"}")
        Text("KNOCK COUNT: ${d.knockCount ?: "--"}")
        Text("KNOCK RETARD °: ${d.knockRetard?.let { "%.1f".format(it) } ?: "--"}")
        Text("MAP kPa: ${d.mapKpa?.let { "%.1f".format(it) } ?: "--"}")
        Text("TPS %: ${d.tps?.let { "%.1f".format(it) } ?: "--"}")
    }
}
